const Shopping_products = [
    {   
        id: 1,
        name: 'Apple airpodss',
        image: 'https://encrypted-tbn0.gstatic.com/shopping?q=tbn:ANd9GcTY0A9OS_CZrVCvV43RrAFsb9DOq1cITvGpYog6XynlvLu7sFNEM7rQeuLlidu3lVSuwF987QJwM0kR7Jmym9q91zq-5Y43aHh06tevZDoYagwHCbFNXxOJ4Q&usqp=CAE',
        price: 500,
        desc:'The fantastic AirPods Pro (2nd Generation),deliver the wireless headphone experience, reimagined '
    },
    {   
        id: 2,
        name: 'Laptop',
        image: 'https://img4.gadgetsnow.com/gd/images/products/additional/large/G424210_View_1/computer-laptop/laptops/msi-titan-gt77-hx-13vi-092in-13th-gen-intel-core-i9-13980hx-17-3-inches-gaming-laptop-64gb-4tb-ssd-windows-11-core-black-3-3-kg-.jpg',
        price: 600,
        desc:'Core i9 and above, 16 to 32GB RAM and a top-end SSD storage unit'
    },
    {   
        id: 3,
        name: 'golduuu',
        image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRxhqB7Mp1kKS70Mmk7i1ekz5Xh6RjRedLzRw&usqp=CAU',
        price: 300,
        desc:'The standard gold bar held  by central banks and bullion dealers is the Good Delivery bar with a 400 ozt (12.4 kg; 27.4 lb) nominal weight.'
    },
    {   
        id: 4,
        name: 'small statue',
        image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS_YDX5YeEJsfuyYpxgB6AP4A2W8jxa3XNzNQ&usqp=CAU',
        price: 200,
        desc:' a piece of miniature art can be held in the palm of the hand, or that it covers less than 25 square inches or 100 cm²'
    },
   
]

export default Shopping_products